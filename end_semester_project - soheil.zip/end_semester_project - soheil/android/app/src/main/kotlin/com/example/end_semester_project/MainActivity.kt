package com.example.end_semester_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
