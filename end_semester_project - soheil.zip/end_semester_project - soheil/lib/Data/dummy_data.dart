import 'package:flutter/material.dart';
import 'package:end_semester_project/models/product_model.dart';
import '../json_decode/network.dart';

class features {
  // Future<String?> search(String title) async {
  //   Network network = await Network(url: 'https://dummyjson.com/products');
  //   List<dynamic> productsData = await network.getdata();
  //
  //   for (int i = 0; i < productsData.length; i++) {
  //     if (productsData[i]['title'] == title) {
  //       return productsData[i]['title'];
  //     }
  //   }
  //
  //   print('No product found with the title: $title');
  //   return null; // Return null if no matching title is found
  // }
  //
  Future<List<Product_features>> putdatainlist() async {
    try {
      Network network = Network(url: 'https://dummyjson.com/products');
      Map<String, dynamic> responseData = await network.getdata();
      if (responseData.containsKey('products') &&
          responseData['products'] is List<dynamic>) {
        List<dynamic> productsData = responseData['products'];
        final List<Product_features> productsList = [];
        for (var productData in productsData) {
          // Check if the productData is a Map and contains the necessary keys
          if (productData is Map<String, dynamic> &&
              productData.containsKey('title') &&
              productData.containsKey('price') &&
              productData.containsKey('brand') &&
              productData.containsKey('thumbnail')&&
              productData.containsKey('description')) {
            Product_features product = Product_features(
              title: productData['title'],
              price: productData['price'],
              brande: productData['brand'],
              image: productData['thumbnail'],
              description: productData['description'],
            );
            productsList.add(product);
          }
        }
        return productsList;
      } else {
        throw Exception(
            'Error: "products" key not found or not a list in the API response');
      }
    } catch (error) {
      throw Exception('Error: $error');
    }
  }
}

List<Product_features> itemsOnBag = [];
