import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BrightnessProvider with ChangeNotifier {
  Brightness _currentBrightness = Brightness.light;

  Brightness get currentBrightness => _currentBrightness;

  void setLightMode() {
    _currentBrightness = Brightness.light;
    notifyListeners();
  }

  void setDarkMode() {
    _currentBrightness = Brightness.dark;
    notifyListeners();
  }
}

class MyProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        brightness: context.watch<BrightnessProvider>().currentBrightness,
        primarySwatch: Colors.blue,
      ),
      home: MyProfilePage(),
    );
  }
}

class MyProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My profile'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundImage: AssetImage('amir.png'),
              radius: 80,
            ),
            SizedBox(
              height: 20,
            ),
            Text("amir drn"),
            Text("Bag: \$ 0"),
            SizedBox(
              height: 100,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    context.read<BrightnessProvider>().setLightMode();
                  },
                  child: Text('Light Mode'),
                ),
                SizedBox(
                  width: 30,
                ),
                ElevatedButton(
                  onPressed: () {
                    context.read<BrightnessProvider>().setDarkMode();
                  },
                  child: Text('Dark Mode'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
