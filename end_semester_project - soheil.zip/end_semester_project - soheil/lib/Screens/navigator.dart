import 'package:end_semester_project/Product_page/Product/bag.dart';
import 'package:end_semester_project/Screens/home-view.dart';



import 'package:end_semester_project/Profile/my_profile.dart';
import 'package:flutter/material.dart';
import 'package:custom_navigation_bar/custom_navigation_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:end_semester_project/loading/loading_screen.dart';


void main() {
  runApp(
    MaterialApp(home: LoadingScreen()), // use MaterialApp
  );
}

class MainNavigator extends StatefulWidget {
  final navigator_new;
  MainNavigator({this.navigator_new});


  @override
  State<MainNavigator> createState() => _MainNavigatorState();
}

class _MainNavigatorState extends State<MainNavigator> {

  PageController _pageController = PageController();
  int _selectedindex = 0;
  List<Widget> _screens = [];

  @override
  void initState() {
    _screens = [


      HomeView(
        product_new: widget.navigator_new,
      ),
      bagView(),

      MyProfile(),
    ];
    // TODO: implement initState
    super.initState();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedindex = index;
    });
    _pageController.animateToPage(_selectedindex, duration: Duration(milliseconds: 200), curve: Curves.linear);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body: PageView(
          controller: _pageController,
          children: _screens,
          physics: AlwaysScrollableScrollPhysics(),
        ),
        bottomNavigationBar: CustomNavigationBar(
          currentIndex: _selectedindex,
          onTap: _onItemTapped,
          iconSize: 27.0,
          bubbleCurve: Curves.linear,
          selectedColor: Color(0xff81C3D7),
          strokeColor: Color(0xff037a9c),
          unSelectedColor: Color(0xff495057),
          backgroundColor: Colors.white,
          scaleFactor: 0.3,
          items: [
            CustomNavigationBarItem(
              icon: Icon(CupertinoIcons.home),
            ),
            CustomNavigationBarItem(
              icon: Icon(CupertinoIcons.shopping_cart),
            ),
            CustomNavigationBarItem(
              icon: Icon(CupertinoIcons.person),
            ),
          ],
        ));
  }
}
