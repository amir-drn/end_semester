import 'package:end_semester_project/Theme/custom-theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../Data/dummy_data.dart';
import '../Product_page/Product/detail_view.dart';
import '../models/product_model.dart';
import 'package:cupertino_icons/cupertino_icons.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeView extends StatefulWidget {
  final product_new;

  HomeView({this.product_new});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  int selectedIndexOfCategory = 0;

  @override
  void initState() {
    print(widget.product_new);
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double w = MediaQuery.of(context).size.width;
    double h = MediaQuery.of(context).size.height;

    Brightness _currentBrightness = Brightness.light;
    return SafeArea(
      child:
        Scaffold(
          body: Column(
            children: [
              SizedBox(
                height: h * 0.1,
                child: Row(
                  children: [
                    Container(
                      width: w,
                      height: h * 0.05,
                      color: Color(0xff071c31),
                      child: ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          itemCount: 30,
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, index) {
                            Product_features model = widget.product_new[index];
                            return GestureDetector(
                              onTap: () {
                                // Navigator.push(context, MaterialPageRoute(builder: (context) => detailView(model: model,)));

                                setState(() {
                                  selectedIndexOfCategory = index;
                                });
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal: w * 0.05,
                                ),
                                child: Text(
                                  model.brande.toString(),
                                  style: TextStyle(
                                    fontSize: selectedIndexOfCategory == index
                                        ? 22
                                        : 18,
                                    color: selectedIndexOfCategory == index
                                        ? Colors.yellow[800]
                                        : Colors.white,
                                    fontWeight: selectedIndexOfCategory == index
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                                  ),
                                ),
                              ),
                            );
                          }),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  Container(
                    width: w * 0.93,
                    height: h * 0.4,
                    child: ListView.builder(
                      itemCount: 10,
                      scrollDirection: Axis.horizontal,
                      physics: BouncingScrollPhysics(),
                      itemBuilder: (context, index) {
                        Product_features model = widget.product_new[index];
                        return GestureDetector(
                          onTap: () {
                             Navigator.push(context,
                                   MaterialPageRoute(
                                       builder: (context) => detailView(model: model,)));
                             },
                          child: Container(
                            margin: EdgeInsets.all(w * 0.01),
                            width: w / 1.5,
                            child: Stack(
                              children: [
                                Container(
                                  width: w / 1.81,
                                  decoration: BoxDecoration(
                                    color: Color(0xffF2AA4C),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                ),
                                Row(
                                  children: [
                                    SizedBox(
                                      width: w * 0.03,
                                    ),
                                    Text(
                                      model.title.toString(),
                                      style: AppThemes.homeProductName,
                                    ),
                                    SizedBox(
                                      width: 130,
                                    ),
                                    IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.favorite,
                                          color: Colors.white,
                                        ))
                                  ],
                                ),
                                Positioned(
                                  top: 35,
                                  left: 10,
                                  child: Text(
                                    model.brande.toString(),
                                    style: AppThemes.homeProductModel,
                                  ),
                                ),
                                Positioned(
                                  top: 75,
                                  left: 10,
                                  child: Text(
                                    "\$${model.price.toString()}",
                                    style: AppThemes.homeProductPrice,
                                  ),
                                ),
                                Positioned(
                                    top: 120,
                                    left: 35,
                                    child: SizedBox(
                                      width: 160,
                                      height: 130,
                                      child:
                                          Image.network(model.image.toString()),
                                    ),
                                  ),

                                Positioned(
                                  bottom: 10,
                                  left: 210,
                                  child: IconButton(
                                      onPressed: () {},
                                      icon: FaIcon(
                                        FontAwesomeIcons.arrowCircleRight,
                                        color: Colors.white,
                                      )),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            title: Padding(
              padding: const EdgeInsets.only(top: 6.0),
              child: Text(
                "Discover",
                style: AppThemes.homeAppBar,
              ),
            ),
            actions: [
              IconButton(
                  onPressed: () {},
                  icon: const Icon(
                    CupertinoIcons.search,
                    color: Colors.black,
                  )),
              IconButton(
                  onPressed: () {},
                  icon: const Icon(
                    CupertinoIcons.bell,
                    color: Colors.black,
                  ))
            ],
          ),
        ),
    );
  }
}
