import 'package:end_semester_project/Theme/custom-theme.dart';
import 'package:end_semester_project/models/models.dart';
import 'package:end_semester_project/Product_page/Product/app_methods.dart';
import 'package:flutter/material.dart';

class detailView extends StatelessWidget {
  const detailView({super.key, required this.model});

  final Product_features model;

  @override
  Widget build(BuildContext context) {
    double w = MediaQuery.of(context).size.width;
    double h = MediaQuery.of(context).size.height;
    return SafeArea(
      child: Scaffold(
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          centerTitle: true,
          title: Text(
            "Nike",
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
          ),
          actions: [
            IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.favorite_border,
                  color: Colors.black,
                ))
          ],
        ),
        body: SizedBox(
          width: w,
          height: h * 1.1,
          child: Column(
            children: [
              SizedBox(
                width: w,
                height: h / 2.3,
                child: Stack(children: [
                  Container(
                      width: 1000,
                      height: h / 2.2,
                      decoration: BoxDecoration(
                          color: Colors.purple,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(1500),
                            bottomRight: Radius.circular(100),
                          ))),
                  Positioned(
                    top: 100,
                    left: 30,
                    child: SizedBox(
                      width: w / 1.3,
                      height: h / 4.3,
                      child: Image.network(
                        model.image.toString(),
                      ),
                    ),
                  ),
                ]),
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                width: w,
                height: h * 0.1,
                color: Colors.red,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(4, (index) => roundedImage(w, h))),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: const Divider(),
              ),
              _productNameandPrice(),
              SizedBox(
                width: 40,
                height: 20,
              ),
              _productInfo(w, h),
              SizedBox(
                height: 40,
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: MaterialButton(
                  color: Colors.purple,
                  height: h / 15,
                  minWidth: w / 1.2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  onPressed: () {
                    appMethods.addToCart(model, context);
                  },
                  child: const Text(
                    "Add to bag",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  _productInfo(width, height) {
    return SizedBox(
      width: width,
      height: height / 9,
      child: Text(
        model.description.toString(),
        style: TextStyle(color: Colors.blue, fontFamily: 'openSans'),
      ),
    );
  }

  _productNameandPrice() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: 20,
        ),
        Text(
          model.brande.toString(),
          style: TextStyle(
            fontSize: 21,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        SizedBox(
          width: 355,
        ),
        Expanded(
            child: Container(
          child: Text(
            "\$${model.price.toString()}",
            style: TextStyle(color: Colors.grey),
          ),
        ))
      ],
    );
  }

  roundedImage(width, height) {
    return Container(
      padding: const EdgeInsets.all(3),
      width: width / 6,
      height: height / 14,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.grey[300],
      ),
      child: Image(image: AssetImage(model.image.toString())),
    );
  }
}
