import 'package:flutter/material.dart';

class emptyState extends StatelessWidget {
  const emptyState({super.key});

  @override
  Widget build(BuildContext context) {
    double w = MediaQuery.of(context).size.width;
    double h = MediaQuery.of(context).size.height;
    return Container(
      width: w,
      height: h / 2,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            " No Product Added",
            style: TextStyle(color: Colors.black),
          ),
          Text(
            " Once You Have Added Come Back",
            style: TextStyle(color: Colors.black),
          ),
        ],
      ),
    );
  }
}
