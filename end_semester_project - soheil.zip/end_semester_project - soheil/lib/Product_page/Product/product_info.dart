
import 'package:flutter/material.dart';
import 'product_info.dart';

class productInfo extends StatelessWidget {
  static String id = "product_info";
  const productInfo({super.key});
  

  @override
  Widget build(BuildContext context) {
    return Text('amir ');
  }
}