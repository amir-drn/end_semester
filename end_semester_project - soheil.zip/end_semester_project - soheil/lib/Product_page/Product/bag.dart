import 'package:end_semester_project/Data/dummy_data.dart';
import 'package:end_semester_project/Theme/custom-theme.dart';
import 'package:end_semester_project/models/models.dart';
import 'package:end_semester_project/Product_page/Product/app_methods.dart';
import 'package:end_semester_project/Product_page/Product/empty_state.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class bagView extends StatefulWidget {
  const bagView({super.key});

  @override
  State<bagView> createState() => _bagViewState();
}

class _bagViewState extends State<bagView> {
  int lenghtOfItemsOnBag = itemsOnBag.length;
  @override
  Widget build(BuildContext context) {
    double w = MediaQuery.of(context).size.width;
    double h = MediaQuery.of(context).size.height;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Container(
            margin: EdgeInsets.symmetric(horizontal: 8),
            width: w,
            height: h,
            child: Column(
              children: [
                SizedBox(
                  width: w,
                  height: h / 14,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "My Bag",
                      style: AppThemes.myBag,
                    ),
                    Text(
                      "Total ${lenghtOfItemsOnBag} Items",
                      style: AppThemes.totalItem,
                    ),
                  ],
                ),
                //not sure
                if (itemsOnBag.isEmpty)
                  emptyState()
                else
                  Container(
                      width: w,
                      height: h / 1.4,
                      color: Colors.white,
                      child: ListView.builder(
                          physics: BouncingScrollPhysics(),
                          scrollDirection: Axis.vertical,
                          itemCount: itemsOnBag.length,
                          itemBuilder: (context, index) {
                            Product_features currenBagItemm = itemsOnBag[index];
                            return Container(
                              margin: EdgeInsets.symmetric(vertical: 4),
                              width: w / 2,
                              height: h * 0.3,
                              // color: Colors.yellow,
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Container(
                                      margin: EdgeInsets.all(20),
                                      width: w / 2,
                                      height: h / 6,
                                      // color: Colors.blue,
                                      child: Stack(
                                        children: [
                                          Positioned.fill(
                                              child: Container(
                                            width: w * 0.37,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(25),
                                                color: Colors.grey),
                                          )),
                                          Positioned(
                                            left: 7,
                                            bottom: 15,
                                            child: Container(
                                              width: 140,
                                              height: 140,
                                              child: Image.network(
                                                  currenBagItemm.image.toString()),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 17,
                                    height: 50,
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          currenBagItemm.title.toString(),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text("\$${currenBagItemm.price}"),
                                        Row(
                                          children: [
                                            GestureDetector(
                                              onTap: () {
                                                setState(() {
                                                  itemsOnBag
                                                      .remove(currenBagItemm);
                                                  lenghtOfItemsOnBag =
                                                      itemsOnBag.length;
                                                });
                                              },
                                              child: Container(
                                                width: 30,
                                                height: 30,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    color: Colors.grey),
                                                child: Icon(
                                                  Icons.remove,
                                                  size: 15,
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 10),
                                              child: const Text("1"),
                                            ),
                                            GestureDetector(
                                              onTap: () {
                                                setState(() {
                                                  itemsOnBag
                                                      .add(currenBagItemm);
                                                  lenghtOfItemsOnBag =
                                                      itemsOnBag.length;
                                                });
                                              },
                                              child: Container(
                                                width: 30,
                                                height: 30,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    color: Colors.grey),
                                                child: Icon(
                                                  Icons.add,
                                                  size: 15,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          })),

                Center(
                    child: Text("Total:  \$${appMethods.sumOfItemsOnBag()}")),
                SizedBox(
                  height: 10,
                ),
                Container(
                  child: materialButton(w, h),
                ),
              ],
            )),
      ),
    );
  }

  materialButton(width, height) {
    return Align(
      alignment: Alignment.center,
      child: MaterialButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        minWidth: width / 2,
        height: height / 20,
        color: Colors.blue,
        onPressed: () {},
        child: Text("Next"),
      ),
    );
  }
}
