import 'package:flutter/material.dart';

class customSnackbar {
  customSnackbar._();

  static successSnackbar() => SnackBar(
        backgroundColor: Colors.green,
        content: const Text("Item Added Succsesfuly"),
        action: SnackBarAction(
          textColor: Colors.white,
          label: 'got it',
          onPressed: () {},
        ),
      );
  static failedSnackbar() => SnackBar(
    backgroundColor: Colors.red,
    content: const Text("You Already have This Item"),
    action: SnackBarAction(
      textColor: Colors.white,
      label: 'got it',
      onPressed: () {},
    ),
  );
}
