import 'package:end_semester_project/Data/dummy_data.dart';
import 'package:end_semester_project/Product_page/Product/custom_snackbar.dart';
import 'package:flutter/material.dart';

import '../../models/product_model.dart';

class appMethods{
  appMethods._();

  static void addToCart( Product_features data , BuildContext context)
  {
    bool contains = itemsOnBag.contains(data);
        if  (contains)
          {
          ScaffoldMessenger.of(context).hideCurrentSnackBar();
          ScaffoldMessenger.of(context).
          showSnackBar(customSnackbar.failedSnackbar());
              }
            else{
              itemsOnBag.add(data);
              ScaffoldMessenger.of(context).hideCurrentSnackBar();
              ScaffoldMessenger.of(context).
              showSnackBar(customSnackbar.successSnackbar());


        }
  }
  static double sumOfItemsOnBag() {
    double sumPrice = 0.0;
    for (Product_features bagModel in itemsOnBag) {
      sumPrice = sumPrice + int.parse(bagModel.price.toString());
    }
    return sumPrice;
  }
}