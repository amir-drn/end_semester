// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class Product_features {
  String? title;
  double? price;
  String? brande;
  String? image;
  String? description;

  Product_features({@required this.title,@required this.price,@required this.brande,@required this.image,@required this.description});
  String toString() {
    return 'Product_features{title: $title, price: $price, brand: $brande, image: $image, description: $description';
  }
}



 
