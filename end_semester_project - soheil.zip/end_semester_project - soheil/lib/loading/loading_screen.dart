import 'package:end_semester_project/Screens/navigator.dart';
import 'package:end_semester_project/models/product_model.dart';
import 'package:flutter/material.dart';
import 'package:end_semester_project/Screens/home-view.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';



import '../Data/dummy_data.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});



  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    load();
  }

  void load() async {
    List<Product_features> p = await features().putdatainlist();
    Navigator.push(context,
      MaterialPageRoute(
        builder: (context) {
          return MainNavigator(
            navigator_new: p,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SpinKitDoubleBounce(
          color: Colors.yellow[800],
          size: 100.0,
        ),
      ),
    );
  }
}
