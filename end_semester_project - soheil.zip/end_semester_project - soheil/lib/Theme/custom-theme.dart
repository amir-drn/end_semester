
import 'package:flutter/material.dart';


class AppThemes {
  AppThemes._();


  static const TextStyle homeAppBar = TextStyle(
      fontSize: 30,
      fontWeight: FontWeight.bold,
      fontFamily: 'gothlic',
      color: Colors.black
  );
  static const TextStyle homeProductName = TextStyle(
      fontSize: 17,
      fontWeight: FontWeight.w500,
      color: Colors.white
  );
  static const TextStyle homeProductModel = TextStyle(
      fontSize: 22,
      fontWeight: FontWeight.bold,
      color: Colors.white
  );
  static const TextStyle homeProductPrice = TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.w400,
      color: Colors.white
  );
  static const TextStyle homeMoreText = TextStyle(
      fontSize: 22,
      fontWeight: FontWeight.bold,
      color: Colors.black
  );
  static const TextStyle emptyState = TextStyle(
      fontSize: 22,
      fontWeight: FontWeight.bold,
      color: Colors.black
  );
  static const TextStyle myBag = TextStyle(
      fontSize: 23,
      fontWeight: FontWeight.w700,
      color: Colors.black
  );
  static const TextStyle totalItem = TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.w200,
      fontFamily: 'openSans',
      color: Colors.black
  );



}