import 'package:http/http.dart' as http;
import 'dart:convert';
class Network
{
  Network({required this.url});
  String url;
  Future getdata()async
  {
    http.Response response = await http.get(Uri.parse(url));
    if(response.statusCode==200) {
      Map<String, dynamic> responseData = json.decode(response.body);
      return responseData;

    } else
    {
      print(response.statusCode);
    }
  }
}